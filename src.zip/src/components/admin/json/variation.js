const VariationJson = {
    "variety": ["color", "weight", "volume", "piece"],
    "color": ["pink", "red", "black", "yellow"],
    "size": ["XS", "S", "M", "L", "XL", "XXL", "XXXL"],
    // "variation": 
    //     {
    //         "color": 
    //             {
    //             "pink":
                
    //                 {
    //                     "size": ["XS", "S", "M", "L", "XL", "XXL", "XXXL"]
    //                 },
                
    //             "red":
                
    //                 {
    //                     "size": ["XS", "S", "M", "L", "XL", "XXL", "XXXL"]
    //                 },
                
    //             "black":
                
    //                 {
    //                     "size": ["XS", "S", "M", "L", "XL", "XXL", "XXXL"]
    //                 },
                
    //             "yellow":
                
    //                 {
    //                     "size": ["XS", "S", "M", "L", "XL", "XXL", "XXXL"]
    //                 },
                
    //             "blue":
                
    //                 {
    //                     "size": ["XS", "S", "M", "L", "XL", "XXL", "XXXL"]
    //                 },
                
    //         }
    //         ,


    //         "weight": [
    //             {
    //             "pink":
    //             [
    //                 {
    //                     "size": ["XS", "S", "M", "L", "XL", "XXL", "XXXL"]
    //                 },
    //             ],
    //             "red":
    //             [
    //                 {
    //                     "size": ["XS", "S", "M", "L", "XL", "XXL", "XXXL"]
    //                 },
    //             ],
    //             "black":
    //             [
    //                 {
    //                     "size": ["XS", "S", "M", "L", "XL", "XXL", "XXXL"]
    //                 },
    //             ],
    //             "yellow":
    //             [
    //                 {
    //                     "size": ["XS", "S", "M", "L", "XL", "XXL", "XXXL"]
    //                 },
    //             ],
    //             "blue":
    //             [
    //                 {
    //                     "size": ["XS", "S", "M", "L", "XL", "XXL", "XXXL"]
    //                 },
    //             ],
    //         }
    //         ],
    //     },

    
}
export default VariationJson;