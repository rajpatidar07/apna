import React from 'react'

 const TranDetail=()=> {
  return (
    <div>Transactions Detail.....</div>
  )
}

export default TranDetail