import React, { useState } from "react";
import Input from "../common/input";
import { ImCross } from "react-icons/im";
import { BsCheckLg } from "react-icons/bs";
import DataTable from "react-data-table-component";
import MainButton from "../common/button";
import Form from "react-bootstrap/Form";
import Iconbutton from "../common/iconbutton";
import SweetAlert from "sweetalert-react";
import "sweetalert/dist/sweetalert.css";

const Pendingproduct = () => {
  const handleAlert = () => setAlert(true);
  const hideAlert = () => setAlert(false);
  const [Alert, setAlert] = useState(false);
  const columns = [
    {
      name: "Sku",
      selector: (row) => <p>{row.sku}</p>,
      sortable: true,
      width: "100px",
      center: true,
    },
    {
      name: "#",
      width: "150px",
      center: true,
      cell: (row) => (
        <img
          height="90px"
          width="70px"
          alt={row.name}
          src={
            "https://images.pexels.com/photos/12547195/pexels-photo-12547195.jpeg?cs=srgb&dl=pexels-fidan-nazim-qizi-12547195.jpg&fm=jpg"
          }
          style={{
            borderRadius: 10,
            paddingTop: 10,
            paddingBottom: 10,
            textAlign: "right",
          }}
          onClick={handleClick}
        />
      ),
    },
    {
      name: "Product Name",
      selector: (row) => row.pname,
      sortable: true,
      width: "290px",
    },
    {
      name: "Category",
      selector: (row) => row.category,
      sortable: true,
      width: "200px",
    },
    {
      name: "Price",
      selector: (row) => row.price,
      sortable: true,
      width: "140px",
      center: true,
      style: {
        paddingRight: "32px",
        paddingLeft: "0px",
      },
    },

    {
      name: "Date",
      selector: (row) => row.date,
      sortable: true,
      width: "150px",
      center: true,
      style: {
        paddingRight: "32px",
        paddingLeft: "0px",
      },
    },
    {
      name: "Action",
      width: "120px",
      style: {
        paddingRight: "12px",
        paddingLeft: "0px",
      },
      selector: (row) => (
        <div>
          <Iconbutton
            onClick={handleAlert}
            btntext={"Approve"}
            btnclass={"btn-sm text-light btn mb-1 bg-success w-100"}
            Iconname={<BsCheckLg className="mx-1" />}
          />
          <Iconbutton
            onClick={handleAlert}
            btntext={"Reject"}
            btnclass={"btn-sm text-light btn bg-danger w-100"}
            Iconname={<ImCross className="mx-1" />}
          />
        </div>
      ),
    },
  ];

  const data = [
    {
      id: 1,
      sku: "9AF4FE",
      pname: (
        <div className="productdescbox">
          <b>
            <p className="mb-0">Green Leaf Lettuce</p>
          </b>

          <p className="productdesc">
            {" "}
            {`The root vegetables include beets, carrots, radishes, sweet potatoes,
            and turnips`}
          </p>
        </div>
      ),
      category: (
        <p className="productdesc">Fruits & Vegetable Fruits & Vegetable</p>
      ),
      price: "$14",
      date: "2022-01-05",
    },
    {
      id: 2,
      sku: "9AF4FE",
      pname: (
        <div className="productdescbox">
          <b>
            <p className="mb-0">Green Leaf Lettuce</p>
          </b>
          <p className="productdesc">
            {" "}
            The root vegetables include beets, and turnips
          </p>
        </div>
      ),
      category: "Fruits & Vegetable",
      price: "$14",
      date: "2022-01-05",
    },
  ];
  const handleClick = () => { };
  return (
    <div>
      <h2>Pending Products</h2>

      {/* search bar */}
      <div className="card mt-3 p-3 ">
        <div className="row pb-3">
          <div className="col-md-3 col-sm-6 aos_input">
            <Input type={"text"} plchldr={"Search by product name"} />
          </div>
          <div className="col-md-3 col-sm-6 aos_input">
            <Form.Select
              aria-label="Search by category"
              className="adminselectbox"
              placeholder="Search by category"
            >
              <option>Search by category</option>
              <option value="1">Food</option>
              <option value="2">Fish & Meat</option>
              <option value="3">Baby Care</option>
            </Form.Select>
          </div>
          <div className="col-md-3 col-sm-6 aos_input">
            <Input type={"date"} plchldr={"Search by product name"} />
          </div>
          <div className="col-md-3 col-sm-6 aos_input">
            <MainButton
              btntext={"Search"}
              btnclass={"button main_button w-100"}
            />
          </div>
        </div>

        {/* upload */}

        {/* datatable */}

        <DataTable
          columns={columns}
          data={data}
          pagination
          highlightOnHover
          pointerOnHover
          className={"table_body pendingproduct_table"}
        />
        <SweetAlert
          show={Alert}
          title="Product Name"
          text="Are you Sure you want to restore"
          onConfirm={hideAlert}
          showCancelButton={true}
          onCancel={hideAlert}
        />
      </div>
    </div>
  );
};

export default Pendingproduct;
